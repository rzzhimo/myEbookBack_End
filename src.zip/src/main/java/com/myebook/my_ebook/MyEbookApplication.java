package com.myebook.my_ebook;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyEbookApplication {

    public static void main(String[] args) {
        SpringApplication.run(MyEbookApplication.class, args);
    }

}
